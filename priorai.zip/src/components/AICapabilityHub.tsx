import React from 'react';
import { 
  Sparkles, Calendar, TrendingUp, Bell, CheckCircle, 
  Mic, GitMerge, ListPlus, Play, RefreshCw, AlertCircle
} from 'lucide-react';
import { Task, Habit, TimeBlock } from '../types';

interface AICapabilityHubProps {
  tasks: Task[];
  habits: Habit[];
  timeBlocks: TimeBlock[];
  gcalUser: any | null;
  autoSyncGCal: boolean;
  onPrioritizeAI: () => void;
  onAutoScheduleAI: () => void;
  onConnectGCal: () => void;
  onTriggerVoiceInfo: () => void;
  activeFocusTask: Task | null;
  setActiveTab: (tab: 'dashboard' | 'tasks' | 'calendar' | 'pillars' | 'chat' | 'hub') => void;
  isAiPrioritizing: boolean;
  isAiScheduling: boolean;
}

export default function AICapabilityHub({
  tasks,
  habits,
  timeBlocks,
  gcalUser,
  autoSyncGCal,
  onPrioritizeAI,
  onAutoScheduleAI,
  onConnectGCal,
  onTriggerVoiceInfo,
  activeFocusTask,
  setActiveTab,
  isAiPrioritizing,
  isAiScheduling
}: AICapabilityHubProps) {
  const activeTasks = tasks.filter(t => t.status !== 'completed');
  
  // Calculate habit stats
  const todayStr = new Date().toISOString().split('T')[0];
  const habitsCompletedToday = habits.filter(h => h.history[todayStr]).length;
  
  // Calculate next deadline
  const upcomingTasks = [...activeTasks].sort((a, b) => 
    new Date(a.deadline).getTime() - new Date(b.deadline).getTime()
  );
  const nextDeadlineTask = upcomingTasks[0];
  
  let deadlineAlert = "No immediate deadlines";
  if (nextDeadlineTask) {
    const diffMs = new Date(nextDeadlineTask.deadline).getTime() - Date.now();
    const diffHrs = Math.ceil(diffMs / (1000 * 60 * 60));
    if (diffHrs < 0) {
      deadlineAlert = `Overdue: "${nextDeadlineTask.title}"`;
    } else if (diffHrs <= 12) {
      deadlineAlert = `Due in ${diffHrs}h: "${nextDeadlineTask.title}" 🚨`;
    } else {
      deadlineAlert = `Due in ${Math.round(diffHrs / 24)} days: "${nextDeadlineTask.title}"`;
    }
  }

  return (
    <div 
      className="bg-white border-4 border-black p-5 rounded-[24px] shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] space-y-4 text-black" 
      id="ai-capability-hub"
    >
      <div className="flex items-center justify-between border-b-2 border-black pb-2">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 bg-[#FFE66D] border-2 border-black rounded-lg flex items-center justify-center text-black shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]">
            <Sparkles className="h-4.5 w-4.5 animate-pulse" />
          </div>
          <div>
            <h4 className="text-sm font-black text-black font-display leading-none">AI Copilot Hub</h4>
            <p className="text-[9px] text-slate-500 font-mono font-bold mt-0.5">8 Active Modules Online</p>
          </div>
        </div>
      </div>

      <div className="space-y-3.5">
        {/* 1. Intelligent Task Prioritization */}
        <div className="flex items-start gap-2.5" id="hub-module-prioritization">
          <div className="h-5 w-5 bg-[#4ECDC4]/20 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <TrendingUp className="h-3.5 w-3.5 text-[#3dbcb3]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Intelligent Task Prioritization</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Online</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Ranks your chaotic tasks based on deadline stress levels.</p>
            <div className="flex gap-2 mt-1.5">
              <button
                id="hub-btn-prioritize"
                onClick={() => {
                  onPrioritizeAI();
                  setActiveTab('tasks');
                }}
                disabled={isAiPrioritizing}
                className="text-[9px] font-black bg-[#4ECDC4] hover:bg-[#3dbcb3] border border-black px-2 py-0.5 rounded shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] flex items-center gap-1"
              >
                {isAiPrioritizing ? "Ranking..." : "AI Rank List"}
              </button>
            </div>
          </div>
        </div>

        {/* 2. AI-Powered Scheduling Assistance */}
        <div className="flex items-start gap-2.5" id="hub-module-scheduling">
          <div className="h-5 w-5 bg-[#FFE66D]/20 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <Calendar className="h-3.5 w-3.5 text-[#ebd04e]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● AI Scheduling Assistance</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Active</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Blocks focus slots on calendar automatically.</p>
            <div className="flex gap-2 mt-1.5">
              <button
                id="hub-btn-schedule"
                onClick={() => {
                  onAutoScheduleAI();
                  setActiveTab('calendar');
                }}
                disabled={isAiScheduling}
                className="text-[9px] font-black bg-[#FFE66D] hover:bg-[#ebd04e] border border-black px-2 py-0.5 rounded shadow-[1px_1px_0px_0px_rgba(0,0,0,1)]"
              >
                {isAiScheduling ? "Scheduling..." : "Auto-Schedule Blockers"}
              </button>
            </div>
          </div>
        </div>

        {/* 3. Personalized Productivity Recommendations */}
        <div className="flex items-start gap-2.5" id="hub-module-recommendations">
          <div className="h-5 w-5 bg-[#FF6B6B]/20 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <Sparkles className="h-3.5 w-3.5 text-[#FF6B6B]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Personalized Recommendations</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Online</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Contextual recommendations updated as backlog moves.</p>
          </div>
        </div>

        {/* 4. Context-Aware Reminders */}
        <div className="flex items-start gap-2.5" id="hub-module-reminders">
          <div className="h-5 w-5 bg-purple-50 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <Bell className="h-3.5 w-3.5 text-purple-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Context-Aware Reminders</p>
              <span className="text-[9px] bg-[#FFE66D] text-black border border-black px-1 rounded font-mono font-black animate-pulse">Live Alert</span>
            </div>
            <p className="text-[10px] text-red-600 font-bold mt-0.5 bg-red-50 p-1 border border-black/10 rounded font-mono">
              🔔 {deadlineAlert}
            </p>
          </div>
        </div>

        {/* 5. Calendar Integration */}
        <div className="flex items-start gap-2.5" id="hub-module-calendar">
          <div className="h-5 w-5 bg-sky-50 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <CheckCircle className="h-3.5 w-3.5 text-sky-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Calendar API Integration</p>
              <span className={`text-[9px] border px-1 rounded font-mono font-bold ${
                gcalUser ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-slate-100 text-slate-600 border-slate-300'
              }`}>
                {gcalUser ? 'Synced' : 'Ready'}
              </span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {gcalUser ? `Connected to ${gcalUser.email}` : "Connect your Google Calendar to auto-sync tasks."}
            </p>
            {!gcalUser && (
              <button
                id="hub-btn-connect-gcal"
                onClick={onConnectGCal}
                className="text-[9px] font-black bg-white hover:bg-slate-100 border border-black px-2 py-0.5 rounded shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] mt-1.5"
              >
                Quick Connect API
              </button>
            )}
          </div>
        </div>

        {/* 6. Goal and Habit Tracking */}
        <div className="flex items-start gap-2.5" id="hub-module-pillars">
          <div className="h-5 w-5 bg-[#4ECDC4]/20 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Goal & Habit Tracking</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Online</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">
              Completed <span className="font-bold text-black">{habitsCompletedToday}/{habits.length}</span> consistency pillars today.
            </p>
            <button
              id="hub-btn-pillars"
              onClick={() => setActiveTab('pillars')}
              className="text-[9px] font-black bg-white hover:bg-slate-100 border border-black px-2 py-0.5 rounded shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] mt-1.5"
            >
              Check Pillars
            </button>
          </div>
        </div>

        {/* 7. Voice-Enabled Assistance */}
        <div className="flex items-start gap-2.5" id="hub-module-voice">
          <div className="h-5 w-5 bg-rose-50 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <Mic className="h-3.5 w-3.5 text-rose-500" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Voice Assistance</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Ready</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">Hands-free task planning. Tap mic in chat companion.</p>
            <button
              id="hub-btn-voice-info"
              onClick={onTriggerVoiceInfo}
              className="text-[9px] font-black bg-white hover:bg-slate-100 border border-black px-2 py-0.5 rounded shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] mt-1.5"
            >
              How to use Voice
            </button>
          </div>
        </div>

        {/* 8. Autonomous Task Planning & Execution */}
        <div className="flex items-start gap-2.5" id="hub-module-milestones">
          <div className="h-5 w-5 bg-indigo-50 border border-black rounded flex items-center justify-center shrink-0 mt-0.5">
            <GitMerge className="h-3.5 w-3.5 text-indigo-600" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="text-xs font-black font-display">● Autonomous Task Planning</p>
              <span className="text-[9px] bg-emerald-100 text-emerald-800 border border-emerald-300 px-1 rounded font-mono font-bold">Online</span>
            </div>
            <p className="text-[10px] text-slate-500 mt-0.5">
              {activeFocusTask 
                ? `Currently planning rescue for: "${activeFocusTask.title}"` 
                : "Generate micro-milestones for any task to start rescue mission."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
