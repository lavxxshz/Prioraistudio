import { Task } from '../types';

/**
 * Creates a Google Calendar event for the given task.
 * @param task The task object
 * @param accessToken OAuth2 Access Token
 * @returns The created event object or null
 */
export async function createGoogleCalendarEvent(task: Task, accessToken: string) {
  try {
    const end = new Date(task.deadline);
    const start = new Date(end.getTime() - task.estimatedDuration * 60 * 1000);

    const event = {
      summary: `${task.title} [PriorAI]`,
      description: task.description || 'Task scheduled via PriorAI',
      start: {
        dateTime: start.toISOString(),
      },
      end: {
        dateTime: end.toISOString(),
      },
      reminders: {
        useDefault: true,
      },
    };

    const response = await fetch(
      'https://www.googleapis.com/calendar/v3/calendars/primary/events',
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event),
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Google Calendar API Error: ${errText}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error creating Google Calendar event:', error);
    throw error;
  }
}
